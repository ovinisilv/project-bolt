/*
  # Create system settings table

  1. New Tables
    - `system_settings`
      - `id` (uuid, primary key)
      - `company_name` (text)
      - `email_notifications` (boolean)
      - `default_currency` (text)
      - `language` (text)
      - `timezone` (text)
      - `theme` (text)
      - `auto_approval_limit` (numeric)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on `system_settings` table
    - Add policies for authenticated users
*/

CREATE TABLE system_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_name text NOT NULL DEFAULT 'Nitro Pay',
  email_notifications boolean NOT NULL DEFAULT true,
  default_currency text NOT NULL DEFAULT 'BRL',
  language text NOT NULL DEFAULT 'pt-BR',
  timezone text NOT NULL DEFAULT 'America/Sao_Paulo',
  theme text NOT NULL DEFAULT 'light',
  auto_approval_limit numeric NOT NULL DEFAULT 1000,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE system_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Enable read access for authenticated users" ON system_settings
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Enable write access for authenticated users" ON system_settings
  FOR ALL TO authenticated USING (true);

-- Create trigger for updated_at
CREATE TRIGGER update_system_settings_updated_at
  BEFORE UPDATE ON system_settings
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();