/*
  # Financial System Tables

  1. New Tables
    - accounts_payable: Manage payable accounts
    - operational_costs: Track operational expenses
    - marketing_campaigns: Monitor marketing performance
    - meds_transactions: Handle MED transactions
    - admin_users: Manage system users
    - system_settings: Store system configuration

  2. Security
    - RLS enabled on all tables
    - Policies for authenticated users
    - Automatic timestamp updates
*/

-- Drop existing triggers if they exist
DROP TRIGGER IF EXISTS update_accounts_payable_updated_at ON accounts_payable;
DROP TRIGGER IF EXISTS update_operational_costs_updated_at ON operational_costs;
DROP TRIGGER IF EXISTS update_marketing_campaigns_updated_at ON marketing_campaigns;
DROP TRIGGER IF EXISTS update_meds_transactions_updated_at ON meds_transactions;
DROP TRIGGER IF EXISTS update_admin_users_updated_at ON admin_users;
DROP TRIGGER IF EXISTS update_system_settings_updated_at ON system_settings;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON accounts_payable;
DROP POLICY IF EXISTS "Enable write access for authenticated users" ON accounts_payable;
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON operational_costs;
DROP POLICY IF EXISTS "Enable write access for authenticated users" ON operational_costs;
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON marketing_campaigns;
DROP POLICY IF EXISTS "Enable write access for authenticated users" ON marketing_campaigns;
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON meds_transactions;
DROP POLICY IF EXISTS "Enable write access for authenticated users" ON meds_transactions;
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON admin_users;
DROP POLICY IF EXISTS "Enable write access for authenticated users" ON admin_users;
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON system_settings;
DROP POLICY IF EXISTS "Enable write access for authenticated users" ON system_settings;

-- Create or replace updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create tables if they don't exist
CREATE TABLE IF NOT EXISTS accounts_payable (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  date date NOT NULL,
  amount numeric NOT NULL,
  status text NOT NULL CHECK (status IN ('pending', 'paid', 'overdue')),
  category text NOT NULL,
  description text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS operational_costs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  category text NOT NULL CHECK (category IN ('fixed', 'variable')),
  amount numeric NOT NULL,
  month date NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS marketing_campaigns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  investment numeric NOT NULL,
  returns numeric NOT NULL,
  cpa numeric NOT NULL,
  cac numeric NOT NULL,
  period date NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS meds_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  date date NOT NULL,
  amount numeric NOT NULL,
  status text NOT NULL CHECK (status IN ('pending', 'approved', 'declined')),
  description text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS admin_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text UNIQUE NOT NULL,
  role text NOT NULL CHECK (role IN ('admin', 'manager', 'user')),
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'blocked')),
  last_login timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS system_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_name text NOT NULL DEFAULT 'Nitro Pay',
  email_notifications boolean NOT NULL DEFAULT true,
  default_currency text NOT NULL DEFAULT 'BRL',
  language text NOT NULL DEFAULT 'pt-BR',
  timezone text NOT NULL DEFAULT 'America/Sao_Paulo',
  theme text NOT NULL DEFAULT 'light',
  auto_approval_limit numeric NOT NULL DEFAULT 1000,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS on all tables
DO $$ 
BEGIN
  EXECUTE 'ALTER TABLE accounts_payable ENABLE ROW LEVEL SECURITY';
  EXECUTE 'ALTER TABLE operational_costs ENABLE ROW LEVEL SECURITY';
  EXECUTE 'ALTER TABLE marketing_campaigns ENABLE ROW LEVEL SECURITY';
  EXECUTE 'ALTER TABLE meds_transactions ENABLE ROW LEVEL SECURITY';
  EXECUTE 'ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY';
  EXECUTE 'ALTER TABLE system_settings ENABLE ROW LEVEL SECURITY';
EXCEPTION 
  WHEN others THEN NULL;
END $$;

-- Create access policies
DO $$ 
BEGIN
  EXECUTE 'CREATE POLICY "Enable read access for authenticated users" ON accounts_payable FOR SELECT TO authenticated USING (true)';
  EXECUTE 'CREATE POLICY "Enable write access for authenticated users" ON accounts_payable FOR ALL TO authenticated USING (true)';
  
  EXECUTE 'CREATE POLICY "Enable read access for authenticated users" ON operational_costs FOR SELECT TO authenticated USING (true)';
  EXECUTE 'CREATE POLICY "Enable write access for authenticated users" ON operational_costs FOR ALL TO authenticated USING (true)';
  
  EXECUTE 'CREATE POLICY "Enable read access for authenticated users" ON marketing_campaigns FOR SELECT TO authenticated USING (true)';
  EXECUTE 'CREATE POLICY "Enable write access for authenticated users" ON marketing_campaigns FOR ALL TO authenticated USING (true)';
  
  EXECUTE 'CREATE POLICY "Enable read access for authenticated users" ON meds_transactions FOR SELECT TO authenticated USING (true)';
  EXECUTE 'CREATE POLICY "Enable write access for authenticated users" ON meds_transactions FOR ALL TO authenticated USING (true)';
  
  EXECUTE 'CREATE POLICY "Enable read access for authenticated users" ON admin_users FOR SELECT TO authenticated USING (true)';
  EXECUTE 'CREATE POLICY "Enable write access for authenticated users" ON admin_users FOR ALL TO authenticated USING (true)';
  
  EXECUTE 'CREATE POLICY "Enable read access for authenticated users" ON system_settings FOR SELECT TO authenticated USING (true)';
  EXECUTE 'CREATE POLICY "Enable write access for authenticated users" ON system_settings FOR ALL TO authenticated USING (true)';
EXCEPTION 
  WHEN others THEN NULL;
END $$;

-- Create triggers for automatic updated_at updates
DO $$ 
BEGIN
  EXECUTE 'CREATE TRIGGER update_accounts_payable_updated_at BEFORE UPDATE ON accounts_payable FOR EACH ROW EXECUTE FUNCTION update_updated_at_column()';
  EXECUTE 'CREATE TRIGGER update_operational_costs_updated_at BEFORE UPDATE ON operational_costs FOR EACH ROW EXECUTE FUNCTION update_updated_at_column()';
  EXECUTE 'CREATE TRIGGER update_marketing_campaigns_updated_at BEFORE UPDATE ON marketing_campaigns FOR EACH ROW EXECUTE FUNCTION update_updated_at_column()';
  EXECUTE 'CREATE TRIGGER update_meds_transactions_updated_at BEFORE UPDATE ON meds_transactions FOR EACH ROW EXECUTE FUNCTION update_updated_at_column()';
  EXECUTE 'CREATE TRIGGER update_admin_users_updated_at BEFORE UPDATE ON admin_users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column()';
  EXECUTE 'CREATE TRIGGER update_system_settings_updated_at BEFORE UPDATE ON system_settings FOR EACH ROW EXECUTE FUNCTION update_updated_at_column()';
EXCEPTION 
  WHEN others THEN NULL;
END $$;