/*
  # Create admin tables

  1. New Tables
    - `accounts_payable`
      - `id` (uuid, primary key)
      - `date` (date)
      - `amount` (numeric)
      - `status` (text)
      - `category` (text)
      - `description` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `operational_costs`
      - `id` (uuid, primary key)
      - `name` (text)
      - `category` (text)
      - `amount` (numeric)
      - `month` (date)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `marketing_campaigns`
      - `id` (uuid, primary key)
      - `name` (text)
      - `investment` (numeric)
      - `returns` (numeric)
      - `cpa` (numeric)
      - `cac` (numeric)
      - `period` (date)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `meds_transactions`
      - `id` (uuid, primary key)
      - `date` (date)
      - `amount` (numeric)
      - `status` (text)
      - `description` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create accounts_payable table
CREATE TABLE accounts_payable (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  date date NOT NULL,
  amount numeric NOT NULL,
  status text NOT NULL,
  category text NOT NULL,
  description text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create operational_costs table
CREATE TABLE operational_costs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  category text NOT NULL,
  amount numeric NOT NULL,
  month date NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create marketing_campaigns table
CREATE TABLE marketing_campaigns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  investment numeric NOT NULL,
  returns numeric NOT NULL,
  cpa numeric NOT NULL,
  cac numeric NOT NULL,
  period date NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create meds_transactions table
CREATE TABLE meds_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  date date NOT NULL,
  amount numeric NOT NULL,
  status text NOT NULL,
  description text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE accounts_payable ENABLE ROW LEVEL SECURITY;
ALTER TABLE operational_costs ENABLE ROW LEVEL SECURITY;
ALTER TABLE marketing_campaigns ENABLE ROW LEVEL SECURITY;
ALTER TABLE meds_transactions ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Enable read access for authenticated users" ON accounts_payable
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Enable write access for authenticated users" ON accounts_payable
  FOR ALL TO authenticated USING (true);

CREATE POLICY "Enable read access for authenticated users" ON operational_costs
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Enable write access for authenticated users" ON operational_costs
  FOR ALL TO authenticated USING (true);

CREATE POLICY "Enable read access for authenticated users" ON marketing_campaigns
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Enable write access for authenticated users" ON marketing_campaigns
  FOR ALL TO authenticated USING (true);

CREATE POLICY "Enable read access for authenticated users" ON meds_transactions
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Enable write access for authenticated users" ON meds_transactions
  FOR ALL TO authenticated USING (true);

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Add updated_at triggers
CREATE TRIGGER update_accounts_payable_updated_at
  BEFORE UPDATE ON accounts_payable
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_operational_costs_updated_at
  BEFORE UPDATE ON operational_costs
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_marketing_campaigns_updated_at
  BEFORE UPDATE ON marketing_campaigns
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_meds_transactions_updated_at
  BEFORE UPDATE ON meds_transactions
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();