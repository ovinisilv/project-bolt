<?php
$menuItems = [
    ['path' => 'dashboard', 'label' => 'Visão Geral', 'icon' => 'layout'],
    ['path' => 'accounts-payable', 'label' => 'Contas a Pagar', 'icon' => 'credit-card'],
    ['path' => 'operational-costs', 'label' => 'Custos Operacionais', 'icon' => 'dollar-sign'],
    ['path' => 'marketing', 'label' => 'Marketing', 'icon' => 'bar-chart'],
    ['path' => 'meds', 'label' => 'MEDs', 'icon' => 'file-text'],
    ['path' => 'users', 'label' => 'Usuários', 'icon' => 'users'],
    ['path' => 'settings', 'label' => 'Configurações', 'icon' => 'settings']
];
?>

<aside class="w-64 bg-white border-r border-gray-200">
    <div class="p-6 border-b border-gray-200">
        <h1 class="text-xl font-bold text-[#3D735F]">Nitro Pay</h1>
    </div>
    <nav class="p-4">
        <ul class="space-y-2">
            <?php foreach ($menuItems as $item): ?>
            <li>
                <a href="?page=<?= $item['path'] ?>" 
                   class="flex items-center px-4 py-2 rounded-lg transition-colors <?= isActive($item['path']) ?>">
                    <i data-feather="<?= $item['icon'] ?>" class="h-5 w-5 mr-3"></i>
                    <?= $item['label'] ?>
                </a>
            </li>
            <?php endforeach; ?>
        </ul>
    </nav>
</aside>