<?php
function isActive($pageName) {
    $currentPage = isset($_GET['page']) ? $_GET['page'] : 'dashboard';
    return $currentPage === $pageName ? 'bg-[#3D735F] text-white' : 'text-gray-600 hover:bg-gray-100';
}
?>