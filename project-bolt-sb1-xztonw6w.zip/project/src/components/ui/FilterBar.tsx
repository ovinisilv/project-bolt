import React from 'react';
import { DashboardFilters } from '../../types';
import { Filter, Calendar, Tag } from 'lucide-react';

interface FilterBarProps {
  filters: DashboardFilters;
  onFilterChange: (filters: Partial<DashboardFilters>) => void;
}

export const FilterBar: React.FC<FilterBarProps> = ({ filters, onFilterChange }) => {
  const transactionTypes = [
    { value: 'all', label: 'Todos os Tipos' },
    { value: 'income', label: 'Receita' },
    { value: 'expense', label: 'Despesa' },
    { value: 'approved', label: 'Aprovado' },
    { value: 'declined', label: 'Recusado' }
  ];

  const expenseCategories = [
    { value: 'all', label: 'Todas as Categorias' },
    { value: 'Servers', label: 'Servidores' },
    { value: 'SaaS', label: 'SaaS' },
    { value: 'Taxes', label: 'Impostos' },
    { value: 'Tools', label: 'Ferramentas' },
    { value: 'fixed', label: 'Custos Fixos' },
    { value: 'variable', label: 'Custos Variáveis' }
  ];

  return (
    <div className="bg-white rounded-lg shadow-sm p-4 mb-6 border border-gray-100">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center">
          <Filter className="w-5 h-5 text-[#3D735F] mr-2" />
          <h2 className="text-lg font-semibold text-gray-800">Filtros</h2>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-4 w-full md:w-auto">
          <div className="relative flex-1">
            <div className="flex items-center">
              <Calendar className="w-4 h-4 text-gray-500 mr-2" />
              <label htmlFor="date-start" className="text-sm font-medium text-gray-600">Período</label>
            </div>
            <div className="flex gap-2 mt-1">
              <input
                type="date"
                id="date-start"
                value={filters.dateRange.start}
                onChange={(e) => onFilterChange({ 
                  dateRange: { ...filters.dateRange, start: e.target.value } 
                })}
                className="border border-gray-300 rounded-md py-1 px-2 text-sm w-full"
              />
              <span className="flex items-center text-gray-500">até</span>
              <input
                type="date"
                id="date-end"
                value={filters.dateRange.end}
                onChange={(e) => onFilterChange({ 
                  dateRange: { ...filters.dateRange, end: e.target.value } 
                })}
                className="border border-gray-300 rounded-md py-1 px-2 text-sm w-full"
              />
            </div>
          </div>

          <div className="relative flex-1">
            <div className="flex items-center">
              <Tag className="w-4 h-4 text-gray-500 mr-2" />
              <label htmlFor="transaction-type" className="text-sm font-medium text-gray-600">Tipo de Transação</label>
            </div>
            <select
              id="transaction-type"
              value={filters.transactionType}
              onChange={(e) => onFilterChange({ transactionType: e.target.value })}
              className="mt-1 border border-gray-300 rounded-md py-1 px-2 text-sm w-full"
            >
              {transactionTypes.map(type => (
                <option key={type.value} value={type.value}>{type.label}</option>
              ))}
            </select>
          </div>

          <div className="relative flex-1">
            <div className="flex items-center">
              <Tag className="w-4 h-4 text-gray-500 mr-2" />
              <label htmlFor="expense-category" className="text-sm font-medium text-gray-600">Categoria de Despesa</label>
            </div>
            <select
              id="expense-category"
              value={filters.expenseCategory}
              onChange={(e) => onFilterChange({ expenseCategory: e.target.value })}
              className="mt-1 border border-gray-300 rounded-md py-1 px-2 text-sm w-full"
            >
              {expenseCategories.map(category => (
                <option key={category.value} value={category.value}>{category.label}</option>
              ))}
            </select>
          </div>
        </div>
      </div>
    </div>
  );
};