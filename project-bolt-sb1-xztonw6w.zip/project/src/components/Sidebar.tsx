import React from 'react';
import { 
  CreditCard, 
  DollarSign, 
  BarChart3, 
  FileText, 
  TrendingUp, 
  Users, 
  BookOpen,
  LayoutDashboard
} from 'lucide-react';

interface SidebarProps {
  activeSection: string;
  onSectionChange: (section: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeSection, onSectionChange }) => {
  const menuItems = [
    { id: 'overview', label: 'Visão Geral', icon: <LayoutDashboard size={20} /> },
    { id: 'accounts-payable', label: 'Contas a Pagar', icon: <CreditCard size={20} /> },
    { id: 'operational-costs', label: 'Custos Operacionais', icon: <DollarSign size={20} /> },
    { id: 'marketing', label: 'Marketing', icon: <BarChart3 size={20} /> },
    { id: 'meds', label: 'Meds', icon: <FileText size={20} /> },
    { id: 'tpv', label: 'TPV Semanal', icon: <TrendingUp size={20} /> },
    { id: 'partners', label: 'Sócios', icon: <Users size={20} /> },
    { id: 'cash-book', label: 'Livro Caixa', icon: <BookOpen size={20} /> }
  ];

  return (
    <div className="hidden md:block w-64 bg-white border-r border-gray-200 overflow-y-auto shadow-sm">
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center justify-center">
          <DollarSign className="h-8 w-8 text-[#3D735F]" />
          <span className="ml-2 text-xl font-bold text-[#3D735F]">Nitro Pay</span>
        </div>
      </div>
      <nav className="mt-4">
        <ul>
          {menuItems.map(item => (
            <li key={item.id}>
              <button
                onClick={() => onSectionChange(item.id)}
                className={`w-full flex items-center px-4 py-3 text-left transition-colors duration-150 ${
                  activeSection === item.id
                    ? 'bg-[#3D735F] text-white'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <span className="mr-3">{item.icon}</span>
                <span>{item.label}</span>
                {activeSection === item.id && (
                  <span className="ml-auto bg-white w-1.5 h-1.5 rounded-full"></span>
                )}
              </button>
            </li>
          ))}
        </ul>
      </nav>
    </div>
  );
};