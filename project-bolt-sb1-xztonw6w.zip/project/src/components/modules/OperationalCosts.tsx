import React from 'react';
import { DashboardFilters } from '../../types';
import Card from '../ui/Card';
import { operationalCostsData } from '../../data/mockData';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';

interface OperationalCostsProps {
  filters: DashboardFilters;
}

export const OperationalCosts: React.FC<OperationalCostsProps> = ({ filters }) => {
  // Filter data based on date range
  const filteredData = operationalCostsData.filter(item => {
    const itemDate = new Date(item.month);
    const startDate = new Date(filters.dateRange.start.substring(0, 7));
    const endDate = new Date(filters.dateRange.end.substring(0, 7));
    
    // Filter by category if selected
    const categoryMatch = filters.expenseCategory === 'all' || 
      item.category === filters.expenseCategory;
    
    return itemDate >= startDate && itemDate <= endDate && categoryMatch;
  });

  // Format for currency
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  // Prepare data for monthly bar chart
  const monthlyData = filteredData.reduce((acc, item) => {
    const month = acc.find(m => m.month === item.month);
    
    if (month) {
      if (item.category === 'fixed') {
        month.fixed += item.amount;
      } else {
        month.variable += item.amount;
      }
      month.total += item.amount;
    } else {
      acc.push({
        month: item.month,
        fixed: item.category === 'fixed' ? item.amount : 0,
        variable: item.category === 'variable' ? item.amount : 0,
        total: item.amount
      });
    }
    
    return acc;
  }, [] as Array<{
    month: string;
    fixed: number;
    variable: number;
    total: number;
  }>);

  // Data for the pie chart showing fixed vs variable distribution
  const categoryTotals = filteredData.reduce((acc, item) => {
    acc[item.category] += item.amount;
    return acc;
  }, { fixed: 0, variable: 0 });

  const categoryData = [
    { name: 'Fixed Costs', value: categoryTotals.fixed },
    { name: 'Variable Costs', value: categoryTotals.variable }
  ];
  
  const COLORS = ['#3D735F', '#5DA17F'];

  // Data for cost breakdown by name
  const costsByName = filteredData.reduce((acc, item) => {
    const existing = acc.find(c => c.name === item.name);
    
    if (existing) {
      existing.value += item.amount;
    } else {
      acc.push({ name: item.name, value: item.amount });
    }
    
    return acc;
  }, [] as Array<{ name: string; value: number }>).sort((a, b) => b.value - a.value);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      <Card title="Monthly Cost Trend" className="col-span-full">
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={monthlyData}
              margin={{
                top: 20,
                right: 30,
                left: 20,
                bottom: 5,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="month" 
                tickFormatter={(value) => {
                  const date = new Date(value);
                  return date.toLocaleDateString('en-US', { month: 'short', year: '2-digit' });
                }}
              />
              <YAxis tickFormatter={(value) => `$${value/1000}k`} />
              <Tooltip 
                formatter={(value) => [formatCurrency(value as number), 'Amount']}
                labelFormatter={(label) => {
                  const date = new Date(label as string);
                  return date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
                }}
              />
              <Legend />
              <Bar dataKey="fixed" name="Fixed Costs" fill="#3D735F" />
              <Bar dataKey="variable" name="Variable Costs" fill="#5DA17F" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>
      
      <Card title="Cost Distribution" className="col-span-1">
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={categoryData}
                cx="50%"
                cy="50%"
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
              >
                {categoryData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value) => [formatCurrency(value as number), 'Amount']} />
            </PieChart>
          </ResponsiveContainer>
        </div>
        
        <div className="mt-4 grid grid-cols-2 gap-4 border-t pt-4">
          <div>
            <p className="text-sm text-gray-500">Total Fixed</p>
            <p className="text-lg font-medium text-[#3D735F]">
              {formatCurrency(categoryTotals.fixed)}
            </p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Total Variable</p>
            <p className="text-lg font-medium text-[#5DA17F]">
              {formatCurrency(categoryTotals.variable)}
            </p>
          </div>
        </div>
      </Card>
      
      <Card title="Cost Breakdown" className="col-span-1 lg:col-span-2">
        <div className="overflow-auto" style={{ maxHeight: '350px' }}>
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50 sticky top-0">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Expense Name
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Category
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Total Amount
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  % of Total
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {costsByName.map((item, index) => {
                const totalExpenses = costsByName.reduce((sum, i) => sum + i.value, 0);
                const percentage = (item.value / totalExpenses) * 100;
                const expense = filteredData.find(e => e.name === item.name);
                
                return (
                  <tr key={index} className="hover:bg-gray-50 transition-colors duration-150">
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-800">
                      {item.name}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {expense?.category === 'fixed' ? 'Fixed' : 'Variable'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {formatCurrency(item.value)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {percentage.toFixed(1)}%
                      <div className="w-full bg-gray-200 rounded-full h-2 mt-1">
                        <div 
                          className="bg-[#3D735F] h-2 rounded-full" 
                          style={{ width: `${percentage}%` }}
                        ></div>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};