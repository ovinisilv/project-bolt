import React from 'react';
import { DashboardFilters } from '../../types';
import Card from '../ui/Card';
import { cashBookData } from '../../data/mockData';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  Legend
} from 'recharts';
import { ArrowUp, ArrowDown } from 'lucide-react';

interface CashBookProps {
  filters: DashboardFilters;
}

export const CashBook: React.FC<CashBookProps> = ({ filters }) => {
  // Filter data based on date range and transaction type
  const filteredData = cashBookData.filter(item => {
    const date = new Date(item.date);
    const startDate = new Date(filters.dateRange.start);
    const endDate = new Date(filters.dateRange.end);
    
    const typeMatch = 
      filters.transactionType === 'all' ||
      (filters.transactionType === 'income' && item.type === 'income') ||
      (filters.transactionType === 'expense' && item.type === 'expense');
    
    return date >= startDate && date <= endDate && typeMatch;
  }).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  // Format currency
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'BRL',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  // Calculate totals
  const totalIncome = filteredData
    .filter(item => item.type === 'income')
    .reduce((sum, item) => sum + item.amount, 0);
    
  const totalExpense = filteredData
    .filter(item => item.type === 'expense')
    .reduce((sum, item) => sum + item.amount, 0);
    
  const netCashFlow = totalIncome - totalExpense;
  
  // Prepare data for charts
  const balanceChartData = filteredData.map(item => ({
    date: item.date,
    balance: item.balance
  }));
  
  // Prepare data for income vs expense chart
  const cashFlowByDate = filteredData.reduce((acc, item) => {
    const date = item.date;
    const existingDate = acc.find(d => d.date === date);
    
    if (existingDate) {
      if (item.type === 'income') {
        existingDate.income += item.amount;
      } else {
        existingDate.expense += item.amount;
      }
    } else {
      acc.push({
        date,
        income: item.type === 'income' ? item.amount : 0,
        expense: item.type === 'expense' ? item.amount : 0
      });
    }
    
    return acc;
  }, [] as Array<{
    date: string;
    income: number;
    expense: number;
  }>);

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <Card title="Cash Balance Trend" className="md:col-span-3">
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart
              data={balanceChartData}
              margin={{
                top: 20,
                right: 30,
                left: 20,
                bottom: 30,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="date" 
                tickFormatter={(value) => {
                  const date = new Date(value);
                  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
                }}
              />
              <YAxis tickFormatter={(value) => `$${value/1000}k`} />
              <Tooltip 
                formatter={(value) => [formatCurrency(value as number), 'Balance']}
                labelFormatter={(label) => {
                  const date = new Date(label as string);
                  return date.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
                }}
              />
              <Area 
                type="monotone" 
                dataKey="balance" 
                stroke="#3D735F" 
                fill="#3D735F20" 
                activeDot={{ r: 8 }} 
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </Card>
      
      <Card title="Income vs Expense" className="md:col-span-2">
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={cashFlowByDate}
              margin={{
                top: 20,
                right: 30,
                left: 20,
                bottom: 30,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="date" 
                tickFormatter={(value) => {
                  const date = new Date(value);
                  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
                }}
              />
              <YAxis tickFormatter={(value) => `$${value/1000}k`} />
              <Tooltip 
                formatter={(value) => [formatCurrency(value as number), 'Amount']}
                labelFormatter={(label) => {
                  const date = new Date(label as string);
                  return date.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
                }}
              />
              <Legend />
              <Bar dataKey="income" name="Income" fill="#3D735F" />
              <Bar dataKey="expense" name="Expense" fill="#E57373" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>
      
      <Card title="Cash Flow Summary" className="md:col-span-1">
        <div className="space-y-6">
          <div>
            <h3 className="text-sm font-medium text-gray-500 mb-2">Receita Total</h3>
            <div className="flex items-center">
              <ArrowUp className="text-green-500 mr-2" size={20} />
              <p className="text-xl font-bold text-green-500">
                {formatCurrency(totalIncome)}
              </p>
            </div>
          </div>
          
          <div>
            <h3 className="text-sm font-medium text-gray-500 mb-2">Despesa Total</h3>
            <div className="flex items-center">
              <ArrowDown className="text-red-500 mr-2" size={20} />
              <p className="text-xl font-bold text-red-500">
                {formatCurrency(totalExpense)}
              </p>
            </div>
          </div>
          
          <div className="border-t pt-4">
            <h3 className="text-sm font-medium text-gray-500 mb-2">Fluxo de Caixa Líquido</h3>
            <div className="flex items-center">
              {netCashFlow >= 0 ? (
                <ArrowUp className="text-green-500 mr-2" size={20} />
              ) : (
                <ArrowDown className="text-red-500 mr-2" size={20} />
              )}
              <p className={`text-xl font-bold ${netCashFlow >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                {formatCurrency(Math.abs(netCashFlow))}
              </p>
            </div>
          </div>
          
          <div className="border-t pt-4">
            <h3 className="text-sm font-medium text-gray-500 mb-2">Saldo Atual</h3>
            <p className="text-2xl font-bold text-[#3D735F]">
              {formatCurrency(filteredData[filteredData.length - 1]?.balance || 0)}
            </p>
          </div>
        </div>
      </Card>
      
      <Card title="Cash Book Entries" className="md:col-span-3">
        <div className="overflow-auto" style={{ maxHeight: '400px' }}>
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50 sticky top-0">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Data
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Descrição
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Tipo
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Valor
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Saldo
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredData.map((entry) => (
                <tr key={entry.id} className="hover:bg-gray-50 transition-colors duration-150">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {new Date(entry.date).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-800">
                    {entry.description}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    {entry.type === 'income' ? (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                        <ArrowUp size={12} className="mr-1" /> Income
                      </span>
                    ) : (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                        <ArrowDown size={12} className="mr-1" /> Expense
                      </span>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <span className={entry.type === 'income' ? 'text-green-600' : 'text-red-600'}>
                      {entry.type === 'income' ? '+' : '-'}{formatCurrency(entry.amount)}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {formatCurrency(entry.balance)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};