import React, { useState } from 'react';
import { DashboardFilters } from '../../types';
import Card from '../ui/Card';
import { marketingData } from '../../data/mockData';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  LineChart,
  Line
} from 'recharts';
import { ArrowUpDown } from 'lucide-react';

interface MarketingManagementProps {
  filters: DashboardFilters;
}

export const MarketingManagement: React.FC<MarketingManagementProps> = ({ filters }) => {
  const [sortField, setSortField] = useState<string>('returns');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');

  // Filter and sort data
  const filteredData = marketingData
    .filter(item => {
      const itemDate = new Date(item.period);
      const startDate = new Date(filters.dateRange.start.substring(0, 7));
      const endDate = new Date(filters.dateRange.end.substring(0, 7));
      
      return itemDate >= startDate && itemDate <= endDate;
    })
    .sort((a, b) => {
      let comparison = 0;
      
      if (sortField === 'name') {
        comparison = a.name.localeCompare(b.name);
      } else if (sortField === 'investment') {
        comparison = a.investment - b.investment;
      } else if (sortField === 'returns') {
        comparison = a.returns - b.returns;
      } else if (sortField === 'roas') {
        comparison = (a.returns / a.investment) - (b.returns / b.investment);
      } else if (sortField === 'cpa') {
        comparison = a.cpa - b.cpa;
      } else if (sortField === 'cac') {
        comparison = a.cac - b.cac;
      }
      
      return sortDirection === 'asc' ? comparison : -comparison;
    });

  // Format currency
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'BRL',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  // Toggle sort
  const toggleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('desc');
    }
  };

  // Group data by campaign for the trend chart
  const campaignNames = [...new Set(marketingData.map(item => item.name))];
  
  // Prepare data for ROI comparison chart
  const roiData = filteredData.map(item => ({
    name: item.name,
    investment: item.investment,
    returns: item.returns,
    roas: parseFloat((item.returns / item.investment).toFixed(2))
  }));

  // Prepare data for campaign performance over time
  const campaignPerformanceData = campaignNames.reduce((acc, campaignName) => {
    const campaignData = marketingData
      .filter(item => item.name === campaignName)
      .sort((a, b) => new Date(a.period).getTime() - new Date(b.period).getTime());
    
    campaignData.forEach(data => {
      const period = data.period;
      const existingPeriod = acc.find(p => p.period === period);
      
      if (existingPeriod) {
        existingPeriod[campaignName] = data.returns / data.investment;
      } else {
        const newPeriod = { period };
        newPeriod[campaignName] = data.returns / data.investment;
        acc.push(newPeriod);
      }
    });
    
    return acc;
  }, [] as Array<Record<string, any>>);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <Card title="Marketing Campaign Performance" className="col-span-full">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  <button 
                    className="flex items-center" 
                    onClick={() => toggleSort('name')}
                  >
                    Campanha
                    <ArrowUpDown size={14} className="ml-1" />
                  </button>
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Período
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  <button 
                    className="flex items-center" 
                    onClick={() => toggleSort('investment')}
                  >
                    Investimento
                    <ArrowUpDown size={14} className="ml-1" />
                  </button>
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  <button 
                    className="flex items-center" 
                    onClick={() => toggleSort('returns')}
                  >
                    Retorno
                    <ArrowUpDown size={14} className="ml-1" />
                  </button>
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  <button 
                    className="flex items-center" 
                    onClick={() => toggleSort('roas')}
                  >
                    ROAS
                    <ArrowUpDown size={14} className="ml-1" />
                  </button>
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  <button 
                    className="flex items-center" 
                    onClick={() => toggleSort('cpa')}
                  >
                    CPA
                    <ArrowUpDown size={14} className="ml-1" />
                  </button>
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  <button 
                    className="flex items-center" 
                    onClick={() => toggleSort('cac')}
                  >
                    CAC
                    <ArrowUpDown size={14} className="ml-1" />
                  </button>
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredData.map((campaign) => {
                const roas = campaign.returns / campaign.investment;
                
                return (
                  <tr key={campaign.id} className="hover:bg-gray-50 transition-colors duration-150">
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-800">
                      {campaign.name}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {new Date(campaign.period).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                      {formatCurrency(campaign.investment)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {formatCurrency(campaign.returns)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">
                      <span className={`px-2 py-1 rounded-full ${
                        roas >= 3 ? 'bg-green-100 text-green-800' : 
                        roas >= 2 ? 'bg-blue-100 text-blue-800' : 
                        roas >= 1 ? 'bg-yellow-100 text-yellow-800' : 
                        'bg-red-100 text-red-800'
                      }`}>
                        {roas.toFixed(2)}x
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                      ${campaign.cpa.toFixed(2)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                      ${campaign.cac.toFixed(2)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>
      
      <Card title="Investment vs Returns" className="col-span-1">
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={roiData}
              margin={{
                top: 20,
                right: 30,
                left: 20,
                bottom: 70,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="name" 
                angle={-45}
                textAnchor="end"
                height={80}
              />
              <YAxis tickFormatter={(value) => `$${value/1000}k`} />
              <Tooltip formatter={(value, name) => [
                formatCurrency(value as number),
                name === 'roas' ? 'ROAS (x)' : name
              ]} />
              <Legend />
              <Bar dataKey="investment" name="Investment" fill="#5DA17F" />
              <Bar dataKey="returns" name="Returns" fill="#3D735F" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>
      
      <Card title="ROAS Trend Over Time" className="col-span-1">
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={campaignPerformanceData}
              margin={{
                top: 20,
                right: 30,
                left: 20,
                bottom: 20,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="period" 
                tickFormatter={(value) => {
                  const date = new Date(value);
                  return date.toLocaleDateString('en-US', { month: 'short', year: '2-digit' });
                }}
              />
              <YAxis 
                domain={[0, 'dataMax + 1']}
                tickFormatter={(value) => `${value.toFixed(1)}x`}
              />
              <Tooltip 
                labelFormatter={(label) => {
                  const date = new Date(label as string);
                  return date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
                }}
                formatter={(value) => [`${Number(value).toFixed(2)}x`, 'ROAS']} 
              />
              <Legend />
              {campaignNames.map((name, index) => {
                const colors = ['#3D735F', '#5DA17F', '#88C5AA'];
                return (
                  <Line 
                    key={index}
                    type="monotone" 
                    dataKey={name} 
                    name={name}
                    stroke={colors[index % colors.length]} 
                    activeDot={{ r: 8 }} 
                  />
                );
              })}
            </LineChart>
          </ResponsiveContainer>
        </div>
      </Card>
    </div>
  );
};