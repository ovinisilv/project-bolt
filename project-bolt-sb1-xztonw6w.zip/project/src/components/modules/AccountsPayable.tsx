import React, { useState } from 'react';
import { DashboardFilters } from '../../types';
import Card from '../ui/Card';
import { accountsPayableData } from '../../data/mockData';
import { 
  PieChart, 
  Pie, 
  Tooltip, 
  Cell, 
  ResponsiveContainer 
} from 'recharts';
import { ArrowUpDown, Check, Clock, AlertCircle } from 'lucide-react';

interface AccountsPayableProps {
  filters: DashboardFilters;
}

export const AccountsPayable: React.FC<AccountsPayableProps> = ({ filters }) => {
  const [sortField, setSortField] = useState<string>('date');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  
  // Sort and filter data
  const filteredData = accountsPayableData
    .filter(item => {
      const date = new Date(item.date);
      const startDate = new Date(filters.dateRange.start);
      const endDate = new Date(filters.dateRange.end);
      
      return date >= startDate && date <= endDate &&
        (filters.expenseCategory === 'all' || item.category === filters.expenseCategory);
    })
    .sort((a, b) => {
      let comparison = 0;
      
      if (sortField === 'date') {
        comparison = new Date(a.date).getTime() - new Date(b.date).getTime();
      } else if (sortField === 'amount') {
        comparison = a.amount - b.amount;
      } else if (sortField === 'status') {
        comparison = a.status.localeCompare(b.status);
      } else if (sortField === 'category') {
        comparison = a.category.localeCompare(b.category);
      }
      
      return sortDirection === 'asc' ? comparison : -comparison;
    });

  // Format currency
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'BRL',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };
  
  // Prepare pie chart data
  const categoryData = filteredData.reduce((acc, item) => {
    const category = acc.find(c => c.name === item.category);
    if (category) {
      category.value += item.amount;
    } else {
      acc.push({ name: item.category, value: item.amount });
    }
    return acc;
  }, [] as { name: string; value: number }[]);
  
  const COLORS = ['#3D735F', '#5DA17F', '#88C5AA', '#B6E0CA', '#DFF5EB'];
  
  // Status label with icon
  const StatusLabel = ({ status }: { status: string }) => {
    if (status === 'paid') {
      return <div className="flex items-center text-green-600"><Check size={16} className="mr-1" /> Pago</div>;
    } else if (status === 'pending') {
      return <div className="flex items-center text-amber-500"><Clock size={16} className="mr-1" /> Pendente</div>;
    } else {
      return <div className="flex items-center text-red-500"><AlertCircle size={16} className="mr-1" /> Atrasado</div>;
    }
  };
  
  // Toggle sort
  const toggleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <Card title="Accounts Payable" className="md:col-span-2">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  <button 
                    className="flex items-center" 
                    onClick={() => toggleSort('date')}
                  >
                    Data
                    <ArrowUpDown size={14} className="ml-1" />
                  </button>
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Descrição
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  <button 
                    className="flex items-center" 
                    onClick={() => toggleSort('category')}
                  >
                    Categoria
                    <ArrowUpDown size={14} className="ml-1" />
                  </button>
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  <button 
                    className="flex items-center" 
                    onClick={() => toggleSort('amount')}
                  >
                    Valor
                    <ArrowUpDown size={14} className="ml-1" />
                  </button>
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  <button 
                    className="flex items-center" 
                    onClick={() => toggleSort('status')}
                  >
                    Situação
                    <ArrowUpDown size={14} className="ml-1" />
                  </button>
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredData.map((item) => (
                <tr key={item.id} className="hover:bg-gray-50 transition-colors duration-150">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {new Date(item.date).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-800">
                    {item.description}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {item.category}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {formatCurrency(item.amount)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <StatusLabel status={item.status} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
      
      <Card title="Expense by Category" className="md:col-span-1">
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={categoryData}
                cx="50%"
                cy="50%"
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
              >
                {categoryData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value) => [formatCurrency(value as number), 'Amount']} />
            </PieChart>
          </ResponsiveContainer>
        </div>
        
        {/* Summary numbers */}
        <div className="mt-6 grid grid-cols-2 gap-4 border-t pt-4">
          <div>
            <p className="text-sm text-gray-500">Total Pendente</p>
            <p className="text-lg font-medium text-amber-500">
              {formatCurrency(
                filteredData
                  .filter(item => item.status === 'pending')
                  .reduce((sum, item) => sum + item.amount, 0)
              )}
            </p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Total Atrasado</p>
            <p className="text-lg font-medium text-red-500">
              {formatCurrency(
                filteredData
                  .filter(item => item.status === 'overdue')
                  .reduce((sum, item) => sum + item.amount, 0)
              )}
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
};