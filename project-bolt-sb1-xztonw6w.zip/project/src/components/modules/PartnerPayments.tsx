import React from 'react';
import { DashboardFilters } from '../../types';
import Card from '../ui/Card';
import { partnerPaymentsData } from '../../data/mockData';
import { 
  PieChart, 
  Pie, 
  Tooltip, 
  Cell, 
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis
} from 'recharts';
import { Users } from 'lucide-react';

interface PartnerPaymentsProps {
  filters: DashboardFilters;
}

export const PartnerPayments: React.FC<PartnerPaymentsProps> = ({ filters }) => {
  // Filter data based on date range
  const filteredData = partnerPaymentsData.filter(item => {
    const date = new Date(item.date);
    const startDate = new Date(filters.dateRange.start);
    const endDate = new Date(filters.dateRange.end);
    
    return date >= startDate && date <= endDate;
  });

  // Format currency
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  // Prepare data for the pie chart
  const partnerTotals = filteredData.reduce((acc, item) => {
    const partner = acc.find(p => p.name === item.partner);
    
    if (partner) {
      partner.value += item.amount;
    } else {
      acc.push({ name: item.partner, value: item.amount });
    }
    
    return acc;
  }, [] as Array<{ name: string; value: number }>);
  
  const COLORS = ['#3D735F', '#5DA17F', '#88C5AA', '#B6E0CA', '#DFF5EB'];
  
  // Prepare data for monthly distributions
  const monthlyDistributions = filteredData.reduce((acc, item) => {
    const date = new Date(item.date);
    const month = date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
    
    // Group by month and partner
    filteredData
      .filter(p => {
        const pDate = new Date(p.date);
        const pMonth = pDate.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
        return pMonth === month;
      })
      .forEach(p => {
        const existingMonth = acc.find(m => m.month === month);
        
        if (existingMonth) {
          existingMonth[p.partner] = (existingMonth[p.partner] || 0) + p.amount;
        } else {
          const newMonth = { month };
          newMonth[p.partner] = p.amount;
          acc.push(newMonth);
        }
      });
    
    return acc;
  }, [] as Array<Record<string, any>>);
  
  // Get unique partner names
  const partnerNames = [...new Set(filteredData.map(item => item.partner))];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <Card title="Partner Distribution" className="md:col-span-1">
        <div className="mb-4 flex items-center justify-center">
          <Users className="h-8 w-8 text-[#3D735F] mr-2" />
          <h3 className="text-lg font-medium text-gray-800">Partnership Shares</h3>
        </div>
        
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={partnerTotals}
                cx="50%"
                cy="50%"
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
              >
                {partnerTotals.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value) => [formatCurrency(value as number), 'Amount']} />
            </PieChart>
          </ResponsiveContainer>
        </div>
        
        <div className="mt-4 border-t pt-4">
          <h4 className="text-sm font-medium text-gray-600 mb-2">Total Distributions</h4>
          <ul className="space-y-2">
            {partnerTotals.map((partner, index) => (
              <li key={index} className="flex items-center justify-between">
                <div className="flex items-center">
                  <div 
                    className="w-3 h-3 rounded-full mr-2" 
                    style={{ backgroundColor: COLORS[index % COLORS.length] }}
                  ></div>
                  <span className="text-sm text-gray-700">{partner.name}</span>
                </div>
                <span className="text-sm font-medium text-gray-900">{formatCurrency(partner.value)}</span>
              </li>
            ))}
          </ul>
        </div>
      </Card>
      
      <Card title="Monthly Distribution" className="md:col-span-2">
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={monthlyDistributions}
              margin={{
                top: 20,
                right: 30,
                left: 20,
                bottom: 20,
              }}
            >
              <XAxis dataKey="month" />
              <YAxis tickFormatter={(value) => `$${value/1000}k`} />
              <Tooltip formatter={(value) => [formatCurrency(value as number), 'Amount']} />
              {partnerNames.map((name, index) => (
                <Bar 
                  key={index} 
                  dataKey={name} 
                  stackId="a" 
                  fill={COLORS[index % COLORS.length]} 
                  name={name}
                />
              ))}
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>
      
      <Card title="Payment Details" className="md:col-span-3">
        <div className="overflow-auto" style={{ maxHeight: '400px' }}>
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50 sticky top-0">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Date
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Partner
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Description
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Amount
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredData.map((payment) => (
                <tr key={payment.id} className="hover:bg-gray-50 transition-colors duration-150">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {new Date(payment.date).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-800">
                    {payment.partner}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {payment.description}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {formatCurrency(payment.amount)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};