import React from 'react';
import { DashboardFilters } from '../../types';
import Card from '../ui/Card';
import { 
  accountsPayableData, 
  operationalCostsData, 
  marketingData, 
  medsTransactionsData, 
  weeklyTpvData, 
  kpiData 
} from '../../data/mockData';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line
} from 'recharts';

interface OverviewProps {
  filters: DashboardFilters;
}

export const Overview: React.FC<OverviewProps> = ({ filters }) => {
  // Format currency function
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'BRL',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  // Filter data based on date range
  const filterByDateRange = (date: string) => {
    const dateObj = new Date(date);
    const startDate = new Date(filters.dateRange.start);
    const endDate = new Date(filters.dateRange.end);
    return dateObj >= startDate && dateObj <= endDate;
  };

  // Filter data for pie chart
  const filteredPayables = accountsPayableData.filter(item => filterByDateRange(item.date));
  
  // Data for accounts payable pie chart
  const categoryCounts = filteredPayables.reduce((acc, item) => {
    acc[item.category] = (acc[item.category] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);
  
  const pieChartData = Object.keys(categoryCounts).map(category => ({
    name: category,
    value: categoryCounts[category]
  }));

  const COLORS = ['#3D735F', '#5DA17F', '#88C5AA', '#B6E0CA', '#DFF5EB'];

  // Data for operational costs bar chart
  const operationalCostsByMonth = operationalCostsData.reduce((acc, item) => {
    const existingMonth = acc.find(m => m.month === item.month);
    if (existingMonth) {
      existingMonth.amount += item.amount;
    } else {
      acc.push({ month: item.month, amount: item.amount });
    }
    return acc;
  }, [] as { month: string, amount: number }[]);

  // Data for meds status pie chart
  const medsStatusData = [
    { name: 'Approved', value: medsTransactionsData.filter(t => t.status === 'approved').length },
    { name: 'Declined', value: medsTransactionsData.filter(t => t.status === 'declined').length }
  ];
  
  const MED_COLORS = ['#3D735F', '#E57373'];

  // Data for TPV line chart
  const tpvData = weeklyTpvData.map(item => ({
    name: item.week,
    value: item.amount
  }));

  // Data for marketing return chart
  const marketingReturnData = marketingData.map(item => ({
    name: item.name,
    investment: item.investment,
    returns: item.returns
  }));

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {/* Accounts Payable Summary */}
      <Card title="Accounts Payable Summary" className="col-span-1">
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={pieChartData}
                cx="50%"
                cy="50%"
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
              >
                {pieChartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value) => [`${value} items`, 'Count']} />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="mt-4 text-center text-sm text-gray-600">
          Categories distribution
        </div>
      </Card>

      {/* Operational Costs Trend */}
      <Card title="Operational Costs Trend" className="col-span-1">
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={operationalCostsByMonth}>
              <XAxis dataKey="month" tickFormatter={(tick) => tick.slice(5)} />
              <YAxis tickFormatter={(tick) => `$${tick/1000}k`} />
              <Tooltip formatter={(value) => [formatCurrency(value as number), 'Amount']} />
              <Bar dataKey="amount" fill="#3D735F" />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="mt-4 text-center text-sm text-gray-600">
          Monthly costs trend
        </div>
      </Card>

      {/* MEDs Status */}
      <Card title="MEDs Status" className="col-span-1">
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={medsStatusData}
                cx="50%"
                cy="50%"
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
              >
                {medsStatusData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={MED_COLORS[index % MED_COLORS.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value) => [`${value} transactions`, 'Count']} />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="mt-4 text-center text-sm text-gray-600">
          Approved vs Declined Transactions
        </div>
      </Card>

      {/* TPV Trend */}
      <Card title="Weekly TPV Trend" className="col-span-1 md:col-span-2">
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={tpvData}>
              <XAxis dataKey="name" />
              <YAxis tickFormatter={(tick) => `$${tick/1000}k`} />
              <Tooltip formatter={(value) => [formatCurrency(value as number), 'Amount']} />
              <Line 
                type="monotone" 
                dataKey="value" 
                stroke="#3D735F" 
                strokeWidth={2}
                dot={{ stroke: '#3D735F', strokeWidth: 2, r: 4 }} 
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="mt-4 text-center text-sm text-gray-600">
          TPV weekly progression
        </div>
      </Card>

      {/* Marketing Return on Investment */}
      <Card title="Marketing ROI" className="col-span-1">
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={marketingReturnData}>
              <XAxis dataKey="name" />
              <YAxis tickFormatter={(tick) => `$${tick/1000}k`} />
              <Tooltip formatter={(value) => [formatCurrency(value as number), 'Amount']} />
              <Bar dataKey="investment" fill="#5DA17F" name="Investment" />
              <Bar dataKey="returns" fill="#3D735F" name="Returns" />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="mt-4 text-center text-sm text-gray-600">
          Investment vs Returns
        </div>
      </Card>

      {/* KPI Summary */}
      <Card title="Key Performance Indicators" className="col-span-1">
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-gray-700">Saldo em Caixa:</span>
            <span className="font-semibold">{formatCurrency(kpiData.cashBalance)}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-gray-700">TPV Atual:</span>
            <span className="font-semibold">{formatCurrency(kpiData.currentTpv)}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-gray-700">MEDs Aprovados:</span>
            <span className="font-semibold">{kpiData.approvedMeds}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-gray-700">Valor MEDs Aprovados:</span>
            <span className="font-semibold">{formatCurrency(kpiData.approvedMedsValue)}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-gray-700">Valor MEDs Recusados:</span>
            <span className="font-semibold">{formatCurrency(kpiData.declinedMedsValue)}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-gray-700">ROAS Médio:</span>
            <span className="font-semibold">{kpiData.totalRoas.toFixed(2)}x</span>
          </div>
        </div>
      </Card>
    </div>
  );
};