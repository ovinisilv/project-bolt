import React from 'react';
import { DashboardFilters } from '../../types';
import Card from '../ui/Card';
import { weeklyTpvData } from '../../data/mockData';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface WeeklyTPVProps {
  filters: DashboardFilters;
}

export const WeeklyTPV: React.FC<WeeklyTPVProps> = ({ filters }) => {
  // Filter data based on date range
  const filteredData = weeklyTpvData.filter(item => {
    const startDate = new Date(item.startDate);
    const endDate = new Date(item.endDate);
    const filterStartDate = new Date(filters.dateRange.start);
    const filterEndDate = new Date(filters.dateRange.end);
    
    // Check if there's an overlap between the week and the filter range
    return (startDate <= filterEndDate && endDate >= filterStartDate);
  });

  // Format currency
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  // Find maximum and minimum weeks
  const sortedByAmount = [...filteredData].sort((a, b) => b.amount - a.amount);
  const maxWeek = sortedByAmount.length > 0 ? sortedByAmount[0] : null;
  const minWeek = sortedByAmount.length > 0 ? sortedByAmount[sortedByAmount.length - 1] : null;
  
  // Calculate growth
  const calculateGrowth = () => {
    if (filteredData.length < 2) return { percentage: 0, positive: true };
    
    const oldestWeek = filteredData[0];
    const newestWeek = filteredData[filteredData.length - 1];
    
    const growth = ((newestWeek.amount - oldestWeek.amount) / oldestWeek.amount) * 100;
    
    return {
      percentage: Math.abs(growth),
      positive: growth >= 0
    };
  };
  
  const growth = calculateGrowth();
  
  // Calculate average weekly growth rate
  const calculateAverageWeeklyGrowth = () => {
    if (filteredData.length < 2) return { percentage: 0, positive: true };
    
    let totalGrowthRate = 0;
    
    for (let i = 1; i < filteredData.length; i++) {
      const prevWeek = filteredData[i - 1];
      const currentWeek = filteredData[i];
      
      const weeklyGrowth = ((currentWeek.amount - prevWeek.amount) / prevWeek.amount) * 100;
      totalGrowthRate += weeklyGrowth;
    }
    
    const avgGrowthRate = totalGrowthRate / (filteredData.length - 1);
    
    return {
      percentage: Math.abs(avgGrowthRate),
      positive: avgGrowthRate >= 0
    };
  };
  
  const avgWeeklyGrowth = calculateAverageWeeklyGrowth();
  
  // Prepare data for the line chart with reference dates
  const chartData = filteredData.map(item => ({
    name: item.week,
    startDate: item.startDate,
    endDate: item.endDate,
    amount: item.amount
  }));

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <Card title="Weekly TPV Overview" className="md:col-span-3">
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart
              data={chartData}
              margin={{
                top: 20,
                right: 30,
                left: 20,
                bottom: 30,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="name" 
                tickFormatter={(value) => value}
              />
              <YAxis 
                tickFormatter={(value) => `$${value/1000}k`} 
              />
              <Tooltip 
                formatter={(value) => [formatCurrency(value as number), 'TPV']}
                labelFormatter={(label) => {
                  const item = chartData.find(item => item.name === label);
                  if (!item) return label;
                  
                  const startDate = new Date(item.startDate).toLocaleDateString();
                  const endDate = new Date(item.endDate).toLocaleDateString();
                  
                  return `${label} (${startDate} - ${endDate})`;
                }}
              />
              <Area 
                type="monotone" 
                dataKey="amount" 
                stroke="#3D735F" 
                fill="#3D735F40" 
                activeDot={{ r: 8 }} 
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </Card>
      
      <Card title="TPV Details" className="md:col-span-1">
        <div className="overflow-auto" style={{ maxHeight: '400px' }}>
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50 sticky top-0">
              <tr>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Week
                </th>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Date Range
                </th>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Amount
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredData.map((week) => (
                <tr key={week.week} className="hover:bg-gray-50 transition-colors duration-150">
                  <td className="px-4 py-3 whitespace-nowrap text-sm font-medium text-gray-800">
                    {week.week}
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">
                    {new Date(week.startDate).toLocaleDateString()} - {new Date(week.endDate).toLocaleDateString()}
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">
                    {formatCurrency(week.amount)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
      
      <Card title="TPV Summary" className="md:col-span-2">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {maxWeek && (
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="text-sm font-medium text-gray-500 mb-2">Highest TPV Week</h3>
              <p className="text-xl font-bold text-[#3D735F]">{maxWeek.week}</p>
              <p className="text-sm text-gray-500 mb-2">
                {new Date(maxWeek.startDate).toLocaleDateString()} - {new Date(maxWeek.endDate).toLocaleDateString()}
              </p>
              <p className="text-lg font-semibold">{formatCurrency(maxWeek.amount)}</p>
            </div>
          )}
          
          {minWeek && (
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="text-sm font-medium text-gray-500 mb-2">Lowest TPV Week</h3>
              <p className="text-xl font-bold text-[#3D735F]">{minWeek.week}</p>
              <p className="text-sm text-gray-500 mb-2">
                {new Date(minWeek.startDate).toLocaleDateString()} - {new Date(minWeek.endDate).toLocaleDateString()}
              </p>
              <p className="text-lg font-semibold">{formatCurrency(minWeek.amount)}</p>
            </div>
          )}
        </div>
        
        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="text-sm font-medium text-gray-500 mb-2">Overall Growth</h3>
            <div className="flex items-center">
              {growth.positive ? (
                <TrendingUp className="text-green-500 mr-2" size={20} />
              ) : (
                <TrendingDown className="text-red-500 mr-2" size={20} />
              )}
              <p className={`text-xl font-bold ${growth.positive ? 'text-green-500' : 'text-red-500'}`}>
                {growth.percentage.toFixed(1)}%
              </p>
            </div>
            <p className="text-sm text-gray-500 mt-1">
              From first to last week
            </p>
          </div>
          
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="text-sm font-medium text-gray-500 mb-2">Average Weekly Growth</h3>
            <div className="flex items-center">
              {avgWeeklyGrowth.positive ? (
                <TrendingUp className="text-green-500 mr-2" size={20} />
              ) : (
                <TrendingDown className="text-red-500 mr-2" size={20} />
              )}
              <p className={`text-xl font-bold ${avgWeeklyGrowth.positive ? 'text-green-500' : 'text-red-500'}`}>
                {avgWeeklyGrowth.percentage.toFixed(1)}%
              </p>
            </div>
            <p className="text-sm text-gray-500 mt-1">
              Week-over-week average
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
};