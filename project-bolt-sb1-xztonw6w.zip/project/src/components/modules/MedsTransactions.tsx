import React from 'react';
import { DashboardFilters } from '../../types';
import Card from '../ui/Card';
import { medsTransactionsData } from '../../data/mockData';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { Check, X } from 'lucide-react';

interface MedsTransactionsProps {
  filters: DashboardFilters;
}

export const MedsTransactions: React.FC<MedsTransactionsProps> = ({ filters }) => {
  // Filter data based on date range and transaction type
  const filteredData = medsTransactionsData.filter(item => {
    const date = new Date(item.date);
    const startDate = new Date(filters.dateRange.start);
    const endDate = new Date(filters.dateRange.end);
    
    const statusMatch = 
      filters.transactionType === 'all' ||
      (filters.transactionType === 'approved' && item.status === 'approved') ||
      (filters.transactionType === 'declined' && item.status === 'declined');
    
    return date >= startDate && date <= endDate && statusMatch;
  });

  // Format currency
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  // Calculate approved and declined totals
  const approvedTotal = filteredData
    .filter(item => item.status === 'approved')
    .reduce((sum, item) => sum + item.amount, 0);
    
  const declinedTotal = filteredData
    .filter(item => item.status === 'declined')
    .reduce((sum, item) => sum + item.amount, 0);

  // Data for the status pie chart
  const statusData = [
    { name: 'Approved', value: filteredData.filter(item => item.status === 'approved').length },
    { name: 'Declined', value: filteredData.filter(item => item.status === 'declined').length }
  ];
  
  const COLORS = ['#3D735F', '#E57373'];
  
  // Data for daily transaction volume
  const dailyData = filteredData.reduce((acc, item) => {
    const date = item.date;
    const existingDate = acc.find(d => d.date === date);
    
    if (existingDate) {
      if (item.status === 'approved') {
        existingDate.approved += item.amount;
      } else {
        existingDate.declined += item.amount;
      }
    } else {
      acc.push({
        date,
        approved: item.status === 'approved' ? item.amount : 0,
        declined: item.status === 'declined' ? item.amount : 0
      });
    }
    
    return acc;
  }, [] as Array<{
    date: string;
    approved: number;
    declined: number;
  }>).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <Card title="MEDs Transactions" className="md:col-span-2">
        <div className="overflow-auto" style={{ maxHeight: '400px' }}>
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50 sticky top-0">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Date
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Description
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Amount
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredData.map((transaction) => (
                <tr key={transaction.id} className="hover:bg-gray-50 transition-colors duration-150">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {new Date(transaction.date).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-800">
                    {transaction.description}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {formatCurrency(transaction.amount)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {transaction.status === 'approved' ? (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                        <Check size={12} className="mr-1" /> Approved
                      </span>
                    ) : (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                        <X size={12} className="mr-1" /> Declined
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
      
      <Card title="Transaction Status" className="md:col-span-1">
        <div className="h-60">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={statusData}
                cx="50%"
                cy="50%"
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
              >
                {statusData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value) => [`${value} transactions`, 'Count']} />
            </PieChart>
          </ResponsiveContainer>
        </div>
        
        <div className="mt-4 grid grid-cols-2 gap-4 border-t pt-4">
          <div>
            <p className="text-sm text-gray-500">Approved Value</p>
            <p className="text-lg font-medium text-green-600">
              {formatCurrency(approvedTotal)}
            </p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Declined Value</p>
            <p className="text-lg font-medium text-red-500">
              {formatCurrency(declinedTotal)}
            </p>
          </div>
        </div>
      </Card>
      
      <Card title="Daily Transaction Volume" className="col-span-full">
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={dailyData}
              margin={{
                top: 20,
                right: 30,
                left: 20,
                bottom: 30,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="date" 
                tickFormatter={(value) => {
                  const date = new Date(value);
                  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
                }}
              />
              <YAxis tickFormatter={(value) => `$${value/1000}k`} />
              <Tooltip 
                formatter={(value) => [formatCurrency(value as number), 'Amount']}
                labelFormatter={(label) => {
                  const date = new Date(label as string);
                  return date.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
                }}
              />
              <Bar dataKey="approved" name="Approved" fill="#3D735F" />
              <Bar dataKey="declined" name="Declined" fill="#E57373" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>
    </div>
  );
};