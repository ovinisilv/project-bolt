import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import { Sidebar } from './Sidebar';
import { Header } from './Header';
import { FilterBar } from './ui/FilterBar';
import { DashboardFilters } from '../types';

export const DashboardLayout = () => {
  const [filters, setFilters] = useState<DashboardFilters>({
    dateRange: {
      start: '2025-03-01',
      end: '2025-04-30',
    },
    transactionType: 'all',
    expenseCategory: 'all',
  });

  const [activeSection, setActiveSection] = useState<string>('overview');

  const handleFilterChange = (newFilters: Partial<DashboardFilters>) => {
    setFilters(prev => ({ ...prev, ...newFilters }));
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar activeSection={activeSection} onSectionChange={setActiveSection} />
        <main className="flex-1 overflow-y-auto p-4 md:p-6">
          <FilterBar filters={filters} onFilterChange={handleFilterChange} />
          <Outlet context={{ activeSection, filters }} />
        </main>
      </div>
    </div>
  );
};