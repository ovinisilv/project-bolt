import React from 'react';
import { kpiData } from '../data/mockData';
import { ArrowUpRight, ArrowDownRight, DollarSign, BarChart3 } from 'lucide-react';

export const Header: React.FC = () => {
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'BRL',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  return (
    <header className="bg-white shadow-sm border-b border-gray-200">
      <div className="px-4 py-3 sm:px-6 flex flex-col sm:flex-row items-center justify-between">
        <div className="flex items-center mb-4 sm:mb-0">
          <DollarSign className="h-8 w-8 text-[#3D735F]" />
          <h1 className="ml-2 text-xl font-semibold text-gray-800">Nitro Pay</h1>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 w-full sm:w-auto">
          <KpiCard 
            title="Saldo em Caixa" 
            value={formatCurrency(kpiData.cashBalance)} 
            icon={<DollarSign className="h-5 w-5" />}
            trend="up"
          />
          <KpiCard 
            title="TPV Atual" 
            value={formatCurrency(kpiData.currentTpv)} 
            icon={<BarChart3 className="h-5 w-5" />}
            trend="up" 
          />
          <KpiCard 
            title="MEDs Aprovados" 
            value={kpiData.approvedMeds.toString()} 
            icon={<ArrowUpRight className="h-5 w-5" />}
            trend="up" 
          />
          <KpiCard 
            title="ROAS Médio" 
            value={kpiData.totalRoas.toFixed(2) + 'x'} 
            icon={<ArrowUpRight className="h-5 w-5" />}
            trend="up" 
          />
        </div>
      </div>
    </header>
  );
};

interface KpiCardProps {
  title: string;
  value: string;
  icon: React.ReactNode;
  trend: 'up' | 'down';
}

const KpiCard: React.FC<KpiCardProps> = ({ title, value, icon, trend }) => {
  return (
    <div className="bg-white rounded-lg p-3 shadow-sm border border-gray-100 transition-all duration-300 hover:shadow-md">
      <div className="flex justify-between items-start">
        <div>
          <p className="text-xs font-medium text-gray-500">{title}</p>
          <p className="text-lg font-semibold text-gray-800">{value}</p>
        </div>
        <div className={`p-2 rounded-full ${trend === 'up' ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-500'}`}>
          {icon}
        </div>
      </div>
    </div>
  );
};