import React from 'react';
import { useOutletContext } from 'react-router-dom';
import { DashboardFilters } from '../types';
import { AccountsPayable } from './modules/AccountsPayable';
import { OperationalCosts } from './modules/OperationalCosts';
import { MarketingManagement } from './modules/MarketingManagement';
import { MedsTransactions } from './modules/MedsTransactions';
import { WeeklyTPV } from './modules/WeeklyTPV';
import { PartnerPayments } from './modules/PartnerPayments';
import { CashBook } from './modules/CashBook';
import { Overview } from './modules/Overview';

interface DashboardContext {
  activeSection: string;
  filters: DashboardFilters;
}

export const Dashboard: React.FC = () => {
  const { activeSection, filters } = useOutletContext<DashboardContext>();

  const renderSection = () => {
    switch (activeSection) {
      case 'overview':
        return <Overview filters={filters} />;
      case 'accounts-payable':
        return <AccountsPayable filters={filters} />;
      case 'operational-costs':
        return <OperationalCosts filters={filters} />;
      case 'marketing':
        return <MarketingManagement filters={filters} />;
      case 'meds':
        return <MedsTransactions filters={filters} />;
      case 'tpv':
        return <WeeklyTPV filters={filters} />;
      case 'partners':
        return <PartnerPayments filters={filters} />;
      case 'cash-book':
        return <CashBook filters={filters} />;
      default:
        return <Overview filters={filters} />;
    }
  };

  return (
    <div className="animate-fadeIn">
      {renderSection()}
    </div>
  );
};