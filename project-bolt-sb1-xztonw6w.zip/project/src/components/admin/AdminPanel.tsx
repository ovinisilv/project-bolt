import React from 'react';
import { Link } from 'react-router-dom';
import { CreditCard, DollarSign, BarChart3, FileText, Users, Settings } from 'lucide-react';

export const AdminPanel = () => {
  const modules = [
    {
      title: 'Contas a Pagar',
      icon: CreditCard,
      description: 'Gerencie fornecedores, vencimentos e status de pagamentos',
      path: '/admin/accounts-payable',
      color: 'bg-blue-500',
    },
    {
      title: 'Custos Operacionais',
      icon: DollarSign,
      description: 'Controle custos fixos e variáveis da operação',
      path: '/admin/operational-costs',
      color: 'bg-green-500',
    },
    {
      title: 'Marketing',
      icon: BarChart3,
      description: 'Acompanhe campanhas, investimentos e retornos',
      path: '/admin/marketing',
      color: 'bg-purple-500',
    },
    {
      title: 'MEDs',
      icon: FileText,
      description: 'Gerencie transações e aprovações',
      path: '/admin/meds',
      color: 'bg-yellow-500',
    },
    {
      title: 'Usuários',
      icon: Users,
      description: 'Administre usuários e permissões',
      path: '/admin/users',
      color: 'bg-red-500',
    },
    {
      title: 'Configurações',
      icon: Settings,
      description: 'Configure parâmetros do sistema',
      path: '/admin/settings',
      color: 'bg-gray-500',
    },
  ];

  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Painel Administrativo</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {modules.map(({ title, icon: Icon, description, path, color }) => (
          <Link
            key={path}
            to={path}
            className="block bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow duration-200"
          >
            <div className="p-6">
              <div className={`inline-flex p-3 rounded-lg ${color} text-white mb-4`}>
                <Icon size={24} />
              </div>
              <h3 className="text-lg font-semibold text-gray-800 mb-2">{title}</h3>
              <p className="text-gray-600">{description}</p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
};