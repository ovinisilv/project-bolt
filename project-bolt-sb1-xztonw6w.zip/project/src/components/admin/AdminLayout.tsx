import React from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import { Settings, Users, CreditCard, DollarSign, BarChart3, FileText, ArrowLeft } from 'lucide-react';

export const AdminLayout = () => {
  const location = useLocation();
  
  const menuItems = [
    { path: 'accounts-payable', label: 'Contas a Pagar', icon: CreditCard },
    { path: 'operational-costs', label: 'Custos Operacionais', icon: DollarSign },
    { path: 'marketing', label: 'Marketing', icon: BarChart3 },
    { path: 'meds-admin', label: 'MEDs', icon: FileText },
    { path: 'users', label: 'Usuários', icon: Users },
    { path: 'settings', label: 'Configurações', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-gray-50 flex">
      <aside className="w-64 bg-white border-r border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <Link to="/" className="flex items-center text-gray-600 hover:text-gray-900 mb-4">
            <ArrowLeft size={20} className="mr-2" />
            Voltar ao Dashboard
          </Link>
          <h1 className="text-xl font-bold text-[#3D735F]">Painel Admin</h1>
        </div>
        <nav className="p-4">
          <ul className="space-y-2">
            {menuItems.map(({ path, label, icon: Icon }) => (
              <li key={path}>
                <Link
                  to={`/admin/${path}`}
                  className={`flex items-center px-4 py-2 rounded-lg transition-colors ${
                    location.pathname === `/admin/${path}`
                      ? 'bg-[#3D735F] text-white'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  <Icon size={20} className="mr-3" />
                  {label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </aside>
      
      <main className="flex-1 p-8 overflow-auto">
        <Outlet />
      </main>
    </div>
  );
};