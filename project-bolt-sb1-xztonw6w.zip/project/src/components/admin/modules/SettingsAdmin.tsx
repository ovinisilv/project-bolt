import React, { useState, useEffect } from 'react';
import { supabase } from '../../../lib/supabase';
import { Save, RefreshCw, Settings as SettingsIcon } from 'lucide-react';

export const SettingsAdmin = () => {
  const [settings, setSettings] = useState({
    companyName: 'Nitro Pay',
    emailNotifications: true,
    defaultCurrency: 'BRL',
    language: 'pt-BR',
    timezone: 'America/Sao_Paulo',
    theme: 'light',
    autoApprovalLimit: 1000
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('system_settings')
        .select('*')
        .single();

      if (error && error.code !== 'PGNF') throw error;
      if (data) setSettings(data);
    } catch (error) {
      console.error('Error fetching settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const { error } = await supabase
        .from('system_settings')
        .upsert(settings);

      if (error) throw error;
    } catch (error) {
      console.error('Error saving settings:', error);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div>Carregando...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex items-center mb-6">
          <SettingsIcon className="h-6 w-6 text-[#3D735F] mr-2" />
          <h2 className="text-lg font-semibold">Configurações do Sistema</h2>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700">Nome da Empresa</label>
              <input
                type="text"
                value={settings.companyName}
                onChange={(e) => setSettings({ ...settings, companyName: e.target.value })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#3D735F] focus:ring-[#3D735F]"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Moeda Padrão</label>
              <select
                value={settings.defaultCurrency}
                onChange={(e) => setSettings({ ...settings, defaultCurrency: e.target.value })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#3D735F] focus:ring-[#3D735F]"
              >
                <option value="BRL">Real Brasileiro (BRL)</option>
                <option value="USD">US Dollar (USD)</option>
                <option value="EUR">Euro (EUR)</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Idioma</label>
              <select
                value={settings.language}
                onChange={(e) => setSettings({ ...settings, language: e.target.value })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#3D735F] focus:ring-[#3D735F]"
              >
                <option value="pt-BR">Português (Brasil)</option>
                <option value="en">English</option>
                <option value="es">Español</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Fuso Horário</label>
              <select
                value={settings.timezone}
                onChange={(e) => setSettings({ ...settings, timezone: e.target.value })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#3D735F] focus:ring-[#3D735F]"
              >
                <option value="America/Sao_Paulo">América/São Paulo</option>
                <option value="America/New_York">América/Nova York</option>
                <option value="Europe/London">Europa/Londres</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Tema</label>
              <select
                value={settings.theme}
                onChange={(e) => setSettings({ ...settings, theme: e.target.value })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#3D735F] focus:ring-[#3D735F]"
              >
                <option value="light">Claro</option>
                <option value="dark">Escuro</option>
                <option value="system">Sistema</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Limite para Aprovação Automática</label>
              <input
                type="number"
                value={settings.autoApprovalLimit}
                onChange={(e) => setSettings({ ...settings, autoApprovalLimit: Number(e.target.value) })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#3D735F] focus:ring-[#3D735F]"
              />
              <p className="mt-1 text-sm text-gray-500">MEDs abaixo deste valor serão aprovados automaticamente</p>
            </div>
          </div>

          <div className="flex items-center mt-4">
            <input
              type="checkbox"
              checked={settings.emailNotifications}
              onChange={(e) => setSettings({ ...settings, emailNotifications: e.target.checked })}
              className="h-4 w-4 text-[#3D735F] focus:ring-[#3D735F] border-gray-300 rounded"
            />
            <label className="ml-2 block text-sm text-gray-900">
              Ativar notificações por email
            </label>
          </div>

          <div className="flex justify-end space-x-4">
            <button
              type="button"
              onClick={fetchSettings}
              className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#3D735F]"
            >
              <RefreshCw className="h-5 w-5 mr-2" />
              Restaurar
            </button>
            <button
              type="submit"
              disabled={saving}
              className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-[#3D735F] hover:bg-[#2D5346] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#3D735F]"
            >
              <Save className="h-5 w-5 mr-2" />
              {saving ? 'Salvando...' : 'Salvar Alterações'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};