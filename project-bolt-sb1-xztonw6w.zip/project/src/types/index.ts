// Types for financial data

export interface Transaction {
  id: string;
  date: string;
  amount: number;
  status: 'pending' | 'paid' | 'overdue';
  category: string;
  description: string;
}

export interface Expense {
  id: string;
  name: string;
  category: 'fixed' | 'variable';
  amount: number;
  month: string;
}

export interface MarketingCampaign {
  id: string;
  name: string;
  investment: number;
  returns: number;
  cpa: number;
  cac: number;
  period: string;
}

export interface MedsTransaction {
  id: string;
  date: string;
  amount: number;
  status: 'approved' | 'declined';
  description: string;
}

export interface WeeklyTPV {
  week: string;
  startDate: string;
  endDate: string;
  amount: number;
}

export interface PartnerPayment {
  id: string;
  partner: string;
  date: string;
  amount: number;
  description: string;
}

export interface CashEntry {
  id: string;
  date: string;
  description: string;
  amount: number;
  balance: number;
  type: 'income' | 'expense';
}

export interface DashboardFilters {
  dateRange: {
    start: string;
    end: string;
  };
  transactionType: string;
  expenseCategory: string;
}