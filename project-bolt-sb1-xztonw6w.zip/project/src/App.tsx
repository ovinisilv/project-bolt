import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { Dashboard } from './components/Dashboard';
import { AdminPanel } from './components/admin/AdminPanel';
import { AccountsPayableAdmin } from './components/admin/modules/AccountsPayableAdmin';
import { OperationalCostsAdmin } from './components/admin/modules/OperationalCostsAdmin';
import { MarketingAdmin } from './components/admin/modules/MarketingAdmin';
import { MedsAdmin } from './components/admin/modules/MedsAdmin';
import { UsersAdmin } from './components/admin/modules/UsersAdmin';
import { SettingsAdmin } from './components/admin/modules/SettingsAdmin';
import { AdminLayout } from './components/admin/AdminLayout';
import { DashboardLayout } from './components/DashboardLayout';

function App() {
  return (
    <Routes>
      <Route path="/" element={<DashboardLayout />}>
        <Route index element={<Dashboard />} />
      </Route>
      <Route path="/admin" element={<AdminLayout />}>
        <Route index element={<Navigate to="/admin/dashboard" replace />} />
        <Route path="dashboard" element={<AdminPanel />} />
        <Route path="accounts-payable" element={<AccountsPayableAdmin />} />
        <Route path="operational-costs" element={<OperationalCostsAdmin />} />
        <Route path="marketing" element={<MarketingAdmin />} />
        <Route path="meds-admin" element={<MedsAdmin />} />
        <Route path="users" element={<UsersAdmin />} />
        <Route path="settings" element={<SettingsAdmin />} />
      </Route>
    </Routes>
  );
}

export default App;