import { 
  Transaction, 
  Expense, 
  MarketingCampaign, 
  MedsTransaction, 
  WeeklyTPV, 
  PartnerPayment, 
  CashEntry 
} from '../types';

// Accounts Payable Data
export const accountsPayableData: Transaction[] = [
  { id: '1', date: '2025-03-01', amount: 2500, status: 'paid', category: 'Servers', description: 'AWS Monthly Services' },
  { id: '2', date: '2025-03-05', amount: 1200, status: 'paid', category: 'SaaS', description: 'CRM Subscription' },
  { id: '3', date: '2025-03-10', amount: 750, status: 'pending', category: 'Taxes', description: 'Monthly Tax Payment' },
  { id: '4', date: '2025-03-15', amount: 1800, status: 'pending', category: 'Servers', description: 'Database Hosting' },
  { id: '5', date: '2025-03-20', amount: 950, status: 'overdue', category: 'Tools', description: 'Development Tools' },
  { id: '6', date: '2025-03-25', amount: 2200, status: 'overdue', category: 'Taxes', description: 'Quarterly Filing Fee' },
  { id: '7', date: '2025-04-01', amount: 1500, status: 'pending', category: 'SaaS', description: 'Data Analytics Platform' },
  { id: '8', date: '2025-04-05', amount: 650, status: 'pending', category: 'Tools', description: 'Security Software' },
];

// Operational Costs Data
export const operationalCostsData: Expense[] = [
  { id: '1', name: 'Salaries', category: 'fixed', amount: 45000, month: '2025-01' },
  { id: '2', name: 'Office Rent', category: 'fixed', amount: 5000, month: '2025-01' },
  { id: '3', name: 'Server Infrastructure', category: 'variable', amount: 8500, month: '2025-01' },
  { id: '4', name: 'Software Licenses', category: 'fixed', amount: 3200, month: '2025-01' },
  { id: '5', name: 'Salaries', category: 'fixed', amount: 45000, month: '2025-02' },
  { id: '6', name: 'Office Rent', category: 'fixed', amount: 5000, month: '2025-02' },
  { id: '7', name: 'Server Infrastructure', category: 'variable', amount: 9200, month: '2025-02' },
  { id: '8', name: 'Software Licenses', category: 'fixed', amount: 3200, month: '2025-02' },
  { id: '9', name: 'Salaries', category: 'fixed', amount: 47000, month: '2025-03' },
  { id: '10', name: 'Office Rent', category: 'fixed', amount: 5000, month: '2025-03' },
  { id: '11', name: 'Server Infrastructure', category: 'variable', amount: 10500, month: '2025-03' },
  { id: '12', name: 'Software Licenses', category: 'fixed', amount: 3500, month: '2025-03' },
];

// Marketing Management Data
export const marketingData: MarketingCampaign[] = [
  { id: '1', name: 'Facebook Ads', investment: 5000, returns: 15000, cpa: 12.5, cac: 25, period: '2025-01' },
  { id: '2', name: 'Google Ads', investment: 7500, returns: 30000, cpa: 10, cac: 18.75, period: '2025-01' },
  { id: '3', name: 'LinkedIn Campaign', investment: 3000, returns: 9000, cpa: 20, cac: 30, period: '2025-01' },
  { id: '4', name: 'Facebook Ads', investment: 5500, returns: 18000, cpa: 11, cac: 22, period: '2025-02' },
  { id: '5', name: 'Google Ads', investment: 8000, returns: 35000, cpa: 9.5, cac: 16, period: '2025-02' },
  { id: '6', name: 'LinkedIn Campaign', investment: 3500, returns: 12000, cpa: 18, cac: 28, period: '2025-02' },
  { id: '7', name: 'Facebook Ads', investment: 6000, returns: 21000, cpa: 10, cac: 20, period: '2025-03' },
  { id: '8', name: 'Google Ads', investment: 9000, returns: 45000, cpa: 8, cac: 15, period: '2025-03' },
  { id: '9', name: 'LinkedIn Campaign', investment: 4000, returns: 15000, cpa: 16, cac: 25, period: '2025-03' },
];

// Meds Transactions Data
export const medsTransactionsData: MedsTransaction[] = [
  { id: '1', date: '2025-03-01', amount: 2500, status: 'approved', description: 'Med Payment - Client A' },
  { id: '2', date: '2025-03-02', amount: 1800, status: 'approved', description: 'Med Payment - Client B' },
  { id: '3', date: '2025-03-03', amount: 3200, status: 'declined', description: 'Med Payment - Client C' },
  { id: '4', date: '2025-03-04', amount: 1500, status: 'approved', description: 'Med Payment - Client D' },
  { id: '5', date: '2025-03-05', amount: 2900, status: 'declined', description: 'Med Payment - Client E' },
  { id: '6', date: '2025-03-06', amount: 1700, status: 'approved', description: 'Med Payment - Client F' },
  { id: '7', date: '2025-03-07', amount: 3500, status: 'approved', description: 'Med Payment - Client G' },
  { id: '8', date: '2025-03-08', amount: 2200, status: 'declined', description: 'Med Payment - Client H' },
];

// Weekly TPV Data
export const weeklyTpvData: WeeklyTPV[] = [
  { week: 'Week 1', startDate: '2025-03-01', endDate: '2025-03-07', amount: 125000 },
  { week: 'Week 2', startDate: '2025-03-08', endDate: '2025-03-14', amount: 142000 },
  { week: 'Week 3', startDate: '2025-03-15', endDate: '2025-03-21', amount: 168000 },
  { week: 'Week 4', startDate: '2025-03-22', endDate: '2025-03-28', amount: 185000 },
  { week: 'Week 5', startDate: '2025-03-29', endDate: '2025-04-04', amount: 172000 },
  { week: 'Week 6', startDate: '2025-04-05', endDate: '2025-04-11', amount: 195000 },
  { week: 'Week 7', startDate: '2025-04-12', endDate: '2025-04-18', amount: 210000 },
  { week: 'Week 8', startDate: '2025-04-19', endDate: '2025-04-25', amount: 205000 },
];

// Partner Payments Data
export const partnerPaymentsData: PartnerPayment[] = [
  { id: '1', partner: 'John Smith', date: '2025-03-05', amount: 15000, description: 'Monthly Distribution' },
  { id: '2', partner: 'Jane Doe', date: '2025-03-05', amount: 15000, description: 'Monthly Distribution' },
  { id: '3', partner: 'Robert Johnson', date: '2025-03-05', amount: 10000, description: 'Monthly Distribution' },
  { id: '4', partner: 'John Smith', date: '2025-04-05', amount: 18000, description: 'Monthly Distribution' },
  { id: '5', partner: 'Jane Doe', date: '2025-04-05', amount: 18000, description: 'Monthly Distribution' },
  { id: '6', partner: 'Robert Johnson', date: '2025-04-05', amount: 12000, description: 'Monthly Distribution' },
];

// Cash Book Data
export const cashBookData: CashEntry[] = [
  { id: '1', date: '2025-03-01', description: 'Opening Balance', amount: 0, balance: 250000, type: 'income' },
  { id: '2', date: '2025-03-01', description: 'Merchant Fees', amount: 15000, balance: 265000, type: 'income' },
  { id: '3', date: '2025-03-02', description: 'Server Payment', amount: 5000, balance: 260000, type: 'expense' },
  { id: '4', date: '2025-03-03', description: 'Merchant Fees', amount: 18000, balance: 278000, type: 'income' },
  { id: '5', date: '2025-03-04', description: 'Marketing Expenses', amount: 8000, balance: 270000, type: 'expense' },
  { id: '6', date: '2025-03-05', description: 'Partner Distributions', amount: 40000, balance: 230000, type: 'expense' },
  { id: '7', date: '2025-03-06', description: 'Merchant Fees', amount: 22000, balance: 252000, type: 'income' },
  { id: '8', date: '2025-03-07', description: 'Software Licenses', amount: 3500, balance: 248500, type: 'expense' },
  { id: '9', date: '2025-03-08', description: 'Merchant Fees', amount: 19500, balance: 268000, type: 'income' },
  { id: '10', date: '2025-03-09', description: 'Office Rent', amount: 5000, balance: 263000, type: 'expense' },
];

// KPI Data
export const kpiData = {
  cashBalance: 263000,
  currentTpv: 195000,
  approvedMeds: medsTransactionsData.filter(t => t.status === 'approved').length,
  totalRoas: marketingData.reduce((acc, campaign) => acc + (campaign.returns / campaign.investment), 0) / marketingData.length,
  approvedMedsValue: medsTransactionsData.filter(t => t.status === 'approved').reduce((acc, t) => acc + t.amount, 0),
  declinedMedsValue: medsTransactionsData.filter(t => t.status === 'declined').reduce((acc, t) => acc + t.amount, 0),
};